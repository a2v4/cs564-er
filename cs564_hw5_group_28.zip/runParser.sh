rm -rf ./*.dat;
python3 ./parser.py ./ebay_data/items-*.json;
# UNCOMMENT FIRST LINE BEFORE SUBMISSION

# COMMENT LINES BELOW BEFORE SUBMISSION, THIS IS ONLY FOR REPO ORGANIZATION
# cd ./parsed_ebay_data;
# python3 ../parser.py ../ebay_data/items-all.json;