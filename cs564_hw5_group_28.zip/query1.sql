--Find the number of users in the database
SELECT COUNT(*) FROM user;

